﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace GTI_2A_EnglishProyect
{
    class Tools
    {
        
        public static bool emptyText(string inputText)
        {

            if (inputText != null)
            {

                
                inputText = inputText.Trim();

                if (inputText.Equals(""))
                {

                    return true;

                }

            }

            return false;

        }

        
        public static string offCapitalsLetters(String inputText)
        {
            inputText = inputText.ToLower();
            String finalText = char.ToUpper(inputText[0]) + inputText.Substring(1);
            if (finalText.Length == 0)
            {
                return "";
            }
            else
            {
                return finalText;
            }


        }

        public static string generateNewID()
        {
            return Guid.NewGuid().ToString();
        }
        
        public static String readFile(String nameFile)
        {
            String line;
            StringBuilder sb = new StringBuilder();


            using (FileStream fs = File.Open(nameFile, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader sr = new StreamReader(fs, Encoding.GetEncoding("utf-8")))
                {
                    while ((line = sr.ReadLine()) != null)
                    {
                        sb.AppendLine(line);
                    }
                }
            }
            return sb.ToString();
        }
        
        public static void dialogError(String title, String message)
        {
            MessageBox.Show(message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

    }
}
