﻿using System;
using System.Windows.Forms;

namespace GTI_2A_EnglishProyect
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
