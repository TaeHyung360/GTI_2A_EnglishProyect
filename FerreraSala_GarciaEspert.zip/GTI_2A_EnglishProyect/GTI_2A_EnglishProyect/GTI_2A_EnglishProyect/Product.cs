﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace GTI_2A_EnglishProyect
{
    public class Product
    {
       
        private string id;
        private string name;
        private string platform;
        private string manufacturer;
        private string description;
        private string price;
        private string stock;
        private string[] availablePlatforms = { "xbox", "playstation", "nintendo", "pc" };
        
        public string ID
        
        {
            get { return id; }
            set
            {
                Console.WriteLine(value);

                if (!Tools.emptyText(id))
                {
                    id = value;
                }
                else
                {
                    throw new ArgumentException("ID cannot be empty");
                }
            }
        }
       
        public string NAME
        
        {
            get { return name; }


            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());

                if (!Tools.emptyText(value))
                {
                    name = Tools.offCapitalsLetters(value);
                }
                else
                {
                    throw new ArgumentException("Name cannot be empty");
                }

            }
        }
        public string PLATFORM
        
        {
            get { return platform; }

            

            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());

                if (validPlatfom(value))
                {
                    platform = Tools.offCapitalsLetters(value);
                }
                else
                {
                    throw new ArgumentException("Invalid platform");

                }

            }
        }
        public string MANUFACTURER
        
        {
            get { return manufacturer; }


            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());

                if (!Tools.emptyText(value))
                {
                    manufacturer = Tools.offCapitalsLetters(value);
                }
                else
                {
                    throw new ArgumentException("Manufacturer cannot be empty");
                }

            }
        }
        public string DESCRIPTION
        
        {
            get { return description; }


            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());
                if (value=="")
                {
                    description = " ";
                }
                else
                {
                    description = Tools.offCapitalsLetters(value);
                }

            }
        }
        public string PRICE
        
        {
            get { return price; }

            

            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());

                if (inpuntPositiveDecimal(value))
                {
                    if (value.Contains("."))
                    {
                        value = value.Replace(".", ",");
                    }
                    price = value;
                }
                else
                {
                    throw new ArgumentException("Price should be a positive number");
                }
            }
        }
        public string STOCK
        
        {
            get { return stock; }
            set
            {
                Console.WriteLine(value);

                value = value.Trim(" ".ToCharArray());


                if (inputPositiveInteger(value))
                {
                    stock = value;
                }
                else
                {
                    throw new ArgumentException("Stock should be a positive integer number");
                }
            }
        }
        
        
        private bool validPlatfom(string type)
        {
            return availablePlatforms.Contains(type.ToLower());
        }
        
        
        
        private bool inputPositiveInteger(string number)
        {

            Match match = Regex.Match(number, @"^[0-9]\d*$");

            return match.Success;

        }
        
        
        private bool inpuntPositiveDecimal(string number)
        {
            Match matchDecimal = Regex.Match(number, @"^[0-9]\d*.\d*$");

            if (matchDecimal.Success)
            {
                return true;
            }

            return false;

        }
        public override string ToString()
        {
            return NAME;
        }
        
        
        
        public Product()
        {
            ID = Tools.generateNewID();

        }
        
        
        public Product(string name, string platform, string manufacturer, string description, string price, string stock)
        {
            ID = Tools.generateNewID();
            NAME = name;
            PLATFORM = platform;
            MANUFACTURER = manufacturer;
            DESCRIPTION = description;
            PRICE = price;
            STOCK = stock;
        }
    }
}
