﻿using System.Collections.Generic;

namespace GTI_2A_EnglishProyect
{
    public class ProductList
    {

        public List<Product> product { get; set; }

    }
}
